mynt gen -f _site && rsync -rupaz _site/ u52703@pyladies.com:remote/
