Charleston PyLadies
==========

From within charleston/

```bash
pip install -r requirements.txt
```

Then from within `charleston/www`

```bash
mynt gen -f _site && mynt serve _site
```
