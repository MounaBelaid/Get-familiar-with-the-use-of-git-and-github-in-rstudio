---
name: Contributors
about: This template should be used for those wishing to join the Project Tech & Infra team as a team member (who is then a contributor to this repository).
title: 'Request to Join Project Tech & Infra: <GitHub Handle>'
labels: contributor
---

_This template should be used (edited) for PyLadies members that wish to join the Project Tech & Infra team.

**Proposed Team Member Details**

Name | GitHub Handle | Slack Handle | PyLadies Chapter | Team Role 
| --| --| --| --|

**Why do you want to join the Project Tech & Infra team?**

/cc @pyladies/pyladies-global-admin @pyladies/tech-and-infra-admins
