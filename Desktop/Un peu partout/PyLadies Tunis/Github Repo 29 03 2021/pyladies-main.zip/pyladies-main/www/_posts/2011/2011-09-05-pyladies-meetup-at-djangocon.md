---
layout: post.html
title: PyLadies Meetup at DjangoCon
tags: [Events]
---

All women at DjangoCon are invited to the PyLadies meetup, Wed night at DjangoCon US!  Thanks to Michelle Rowley and Eric Holscher (both of PDX Python) for organizing and planning the party.

Gents who participate in IRC channel \#pyladies and guests of women are invited too.

Wednesday, September 7, 2011 8pm onward Location: Ringlers Annex of McMenamins

(Note: this is the Annex a block east of Ringlers, not Ringlers itself) 1223 S.W. Stark Portland, OR 97205 (503) 384-2700

[http://www.mcmenamins.com/250-ringlers-annex-home](http://www.mcmenamins.com/250-ringlers-annex-home)


By [Audrey Roy](https://twitter.com/audreyr "AudreyR | Twitter")

[Tweet](https://twitter.com/share)