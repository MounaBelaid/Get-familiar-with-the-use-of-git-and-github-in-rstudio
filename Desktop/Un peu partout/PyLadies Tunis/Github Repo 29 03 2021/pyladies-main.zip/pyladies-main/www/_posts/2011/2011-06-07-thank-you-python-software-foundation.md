---
layout: post.html
title: Thank you, Python Software Foundation!
tags: [Announcements]
---


It's true:

We are so incredibly grateful to the PSF for taking a chance and stepping up to help us in a big way. We have more to say about this and how it has impacted us, so stay tuned.

By [Audrey Roy](https://twitter.com/audreyr "AudreyR | Twitter")

[Tweet](https://twitter.com/share)