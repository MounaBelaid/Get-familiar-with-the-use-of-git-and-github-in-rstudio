---
layout: post.html
title: Djangsta Shirts on Sale at DjangoCon
tags: [DjangoCon]
---

These "Djangsta" shirts premiered at DjangoCon to a rousing success and are selling out quickly! If you are coming to DjangoCon this year, find a PyLady and get one! Proceeds help PyLadies outreach efforts. Shirt logo was designed by xtine.

Available: Womens L, Mens S/L

A pre-order form will be available for a reprint run!

![image0](http://i.imgur.com/7epc8.png) Model: [Jeff Schenck](https://twitter.com/#!/jeffschenck)


By [C Cheung](https://twitter.com/plaidxtine "Plaidxtine | Twitter")

[Tweet](https://twitter.com/share)