---
layout: post.html
title: "Speaking at PyCon, DjangoCon, etc"
tags: [speaking, conferences]
category: [resources]
---

Speaking at conferences about Python is a great way to give back to the community with your own knowledge.

* [We Are All Awesome][awesome]: hosts IRC office hours to help women speakers.
* [Protips on Conference Talks][craig]: Thinking about giving a talk at a conference? Here is some great advice on how to rock it!
* [SpeakUp.io][speak]


[awesome]: http://weareallaweso.me/
[craig]: http://craigkerstiens.com/2012/06/19/pro-tips-for-conference-talks/
[speak]: http://speakup.io