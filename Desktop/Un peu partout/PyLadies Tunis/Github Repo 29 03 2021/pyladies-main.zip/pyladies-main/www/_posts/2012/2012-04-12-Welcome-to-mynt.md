---
layout: post.html
title: Welcome to mynt
tags: [Initial]
---

For a quick overview of what mynt has to offer, give the [quickstart][quickstart] guide a read. You can also find API reference style documentation on the [docs][docs] page. If you run into any problems open an issue on [GitHub][github]. Lastly, if you have any questions or just want to chat, you can hop into our IRC channel on [freenode][freenode], #mynt.


[docs]: http://mynt.mirroredwhite.com/docs/
[freenode]: http://webchat.freenode.net/?channels=mynt
[github]: https://github.com/Anomareh/mynt
[quickstart]: http://mynt.mirroredwhite.com/quickstart/
