---
layout: post.html
title: "Libraries"
tags: [libraries]
category: [resources]
---


[Code checking using PEP-8 + PyFlakes][flake8]: Are you writing code according to the standard Python guidelines?  Have no idea?  Try out this library
[Logr][simple]: Simple Python blogger
[Git Legit][git]: Git for Humans

[flake8]: https://crate.io/packages/flake8/
[simple]: https://github.com/BrewerHimself/Logr
[git]: https://github.com/kennethreitz/legit