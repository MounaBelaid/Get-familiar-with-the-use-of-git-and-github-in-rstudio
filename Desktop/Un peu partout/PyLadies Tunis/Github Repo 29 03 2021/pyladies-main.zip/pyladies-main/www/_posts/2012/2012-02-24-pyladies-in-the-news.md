---
layout: post.html
title: PyLadies in the News
tags: [Updates]
---

The LA Weekly blog featured a few of the LA PyLadies in a [recent post.](http://blogs.laweekly.com/arts/2012/02/pyladies_django_python.php) The Open Hatchery highlights a nice example of the [power of community collaboration](https://openhatch.org/blog/2012/diversifying-pycon-the-power-of-cooperative-outreach/) and outreach (we can't wait to meet Pam at PyCon!)

We've even stirred a bit of discussion on [Reddit](http://www.reddit.com/r/programming/comments/psnr6/geek_chicks_pyladies_a_gang_of_female_computer/) -- care to join the fray? =)

By [Esther Nam](https://twitter.com/estherbester "Estherbester | Twitter")

[Tweet](https://twitter.com/share)