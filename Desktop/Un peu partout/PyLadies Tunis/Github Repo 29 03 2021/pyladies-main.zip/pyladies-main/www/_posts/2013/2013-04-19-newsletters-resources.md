---
layout: post.html
title: "Newsletters"
tags: [newsletters, weeklies, email]
category: [resources]
---

* [Python Weekly][python] is a free weekly newsletter all about Python (articles, news, jobs, etc).
* [Pycoders Weekly][pycoders] is a free weekly python newsletter for Python developers by Python developers (Project, Articles, News, and Jobs).

[python]: http://www.pythonweekly.com
[pycoders]: http://pycoders.com