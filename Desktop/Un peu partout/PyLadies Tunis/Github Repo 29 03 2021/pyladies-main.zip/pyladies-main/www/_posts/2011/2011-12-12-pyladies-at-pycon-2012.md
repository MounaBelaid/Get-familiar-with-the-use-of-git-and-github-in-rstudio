---
layout: post.html
title: PyLadies at PyCon 2012
tags: [PyCon]
---

We're happy to announce that with the help of the Python Software Foundation, PyLadies will be making an appearance at [PyCon](http://us.pycon.org/2012) 2012! We will be exhibiting during the main portion of conference and will be on hand to help any other interested PyLadies in joining or starting up their own chapter. We will soon have details about grants to attend this upcoming PyCon, so stay tuned!

By [C Cheung](https://twitter.com/plaidxtine "Plaidxtine | Twitter")

[Tweet](https://twitter.com/share)