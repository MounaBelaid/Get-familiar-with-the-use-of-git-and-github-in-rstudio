---
layout: post.html
title: Djangsta Shirts - Extra Print Run!
tags: [Django]
---

If you were at DjangoCon you probably saw people wearing these, standing out magnificently amongst the sea of bright green. They were the cool people -- the Djangstas, if you will.

We were originally going to sell these only at DjangoCon, but demand was so high we've decided to do one more print run. If you  hesitated the first time around (and are now full of regret), or were shortsighted enough to give DjangoCon a miss altogether this year (and are now SO full of regret), here's your chance to redeem yourself and join the ranks of the Djangstas!

Shirts will now cost $25, to cover shipping and/or PayPal fees.

**Please pre-order by October 1,** by filling out the form below. We'll email you to confirm so you can pay us (via check or Paypal)  before we print and mail you your shirt.

* * * * *

**Update**

**[The pre-order period has ended: Thanks to everyone who placed their orders! We will be contacting you shortly to collect payments and mailing addresses, so dig up that checkbook or dust off your Paypal account! :)]**



By [Esther Nam](https://twitter.com/estherbester "Estherbester | Twitter")

[Tweet](https://twitter.com/share)