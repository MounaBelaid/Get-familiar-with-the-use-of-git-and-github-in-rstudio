---
layout: post.html
title: Great turnout at the Python Ladies Night 3
tags: [Conferences]
---

We had around 14 people come and go throughout the night. It was a blast! We talked Python but also other things. Did you know that there are enough of us who ride scooters/motorcycles that we could have our very own PyLadies rally club?

Attendees were mostly Python developer ladies, but also a few gentlemen of the Python community and possibly one guy who doesn't know Python (yet ;) Here are some of us:

Sad that you missed it? Come for the next one! It'll be right after the PyLadies Hack Session. Even if you can't make it to the event, you can still join us for drinks afterward.

SAVE THE DATE
-------------

Python Ladies' Night 4 will be on Saturday, June 18 from 8pm onward, at Hollywood Canteen, 1006 Seward St, Los Angeles, CA 90038.


By [Audrey Roy](https://twitter.com/audreyr "AudreyR | Twitter")

[Tweet](https://twitter.com/share)