---
layout: post.html
title: SF Study Group
tags: [Events]
---

Udacity is offering a free online intro to programming course starting Monday April 16th. Each week, videos will be posted online at the start of the week and homework will be due on the Tuesday of the following week.

Let's meet every Wednesday evening; exact time & place will be coordinated with soon, but will be in the SF city area.

Please watch the videos beforehand so we can work on homework together. There are multiple courses, no need to all do the same. We can help each other!

Also - this event is for women, those who identify as women, and their friends (of either gender). Emphatically queer & trans friendly.

See [PyLadies SF event page](http://www.meetup.com/PyLadiesSF/events/62203752/)

By [Esther Nam](https://twitter.com/estherbester "Estherbester | Twitter")

[Tweet](https://twitter.com/share)