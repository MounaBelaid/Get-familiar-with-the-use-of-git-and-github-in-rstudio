mynt gen -f _site && mynt serve _site
