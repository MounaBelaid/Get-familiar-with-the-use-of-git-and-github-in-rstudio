### HOW TO

Clone this repo, then put your website in this directory, `sandiego`. It can use [mynt](http://mynt.mirroredwhite.com/) - a static site generator like how the main [PyLadies](https://github.com/pyladies/pyladies/tree/master/www) uses - or build your own using some other framework or static site generator.

When ready, do a pull request to master within `sandiego` directory AS WELL AS change the link that's in [Locations](https://github.com/pyladies/pyladies/blob/master/www/locations/index.html#L44-48) that directs to www.pyladies.com/sd (just a dummy page).


