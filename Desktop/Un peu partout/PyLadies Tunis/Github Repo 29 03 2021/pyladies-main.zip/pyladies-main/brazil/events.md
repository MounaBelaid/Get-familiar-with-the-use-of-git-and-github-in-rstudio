---
layout: page
title: Eventos
permalink: /events/
tab: true
icon: icon-calendar
order: 2
---

Não perca os próximos eventos do PyLadies Brasil:

* [PyLadies Recife]({{site.baseurl}}/recife/recife/)

 
Eventos Passados:

* [PyLadies Natal](http://pyladiesnatal.github.io/)

