---
layout: default_event
title: PyLadies Recife
tab_recife: true
icon: icon-bullhorn
order: 1
---
<br>
<br>
O **PyLadies Recife** vai acontecer no dia **06 de Setembro** e nós queremos ver você lá!
<br>

Vamos promover um espaço de aprendizado para mulheres que tem vontade de conhecer o mundo da programação. E, além de apresentar, colocaremos a mão na massa para construirmos algo juntas!

