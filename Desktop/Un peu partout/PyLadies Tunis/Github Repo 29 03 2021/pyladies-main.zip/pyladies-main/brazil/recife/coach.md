---
layout: default_event
title: Quero ser Coach
tab_recife: true
icon: icon-female
order: 4
---
<h5>Quer ser Coach do PyLadies Recife? É fácil!</h5>
<p>Você pode compartilhar um pouco do seu conhecimento sobre Python e sua experiência mentorando pyladies no nosso primeiro encontro em Recife.</p>
<div class="row">
<iframe src="https://docs.google.com/forms/d/1eHotml8hN7uFmbEnl2p0xKMSJgMCgjjz8k6pNq_-dzo/viewform?embedded=true" width="100%" height="500" frameborder="0" marginheight="0" marginwidth="0">Carregando...</iframe>
</div> 
