---
layout: page
title: Crie seu próprio grupo
permalink: /join/
---

####Então você decidiu começar seu próprio grupo PyLadies \o

Estamos muito animadas para ter pessoas como você se juntando à nossa comunidade e queremos ajudá-la a criar o seu grupo Pyladies da melhor forma possível, rápido e sem estresses ;) Pela nossa experiência, podemos garantir que o seu primeiro grande evento irá estimular e inspirar a comunidade Python em sua área e criar uma dinâmica para eventos posteriores, por isso é fundamental começar as coisas com o pé direito!

Para ajudar você a começar, criamos um [kit][kitgit] de código aberto para iniciar o seu próprio grupo PyLadies em sua cidade, além disso temos um [Handbook][handbook] com regras e dicas. Visite nossa página no [Facebook][pyladiesbrF] e nosso [Twitter][pyladiesbrT]. Também pedimos que nos envie um <a href="mailto:brazil@pyladies.com">email</a> expressando seu desejo de montar um grupo ai.

Você também pode ver informações sobre as outras cidades que possuem o PyLadies, sinta-se a vontade para tê-las como modelo.

[handbook]:       http://pyladies-brasil-handbook.readthedocs.org/en/latest/
[pyladiesbrT]:    https://twitter.com/PyLadiesBrazil
[pyladiesbrF]:    https://www.facebook.com/PyLadiesBrazil?ref_type=bookmark
[kitgit]:         https://github.com/PyLadiesBr
