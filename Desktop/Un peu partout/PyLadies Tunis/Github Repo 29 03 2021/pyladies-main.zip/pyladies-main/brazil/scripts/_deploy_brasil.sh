jekyll build && rsync -rupaz _site/ u52703@pyladies.com:brasil/
