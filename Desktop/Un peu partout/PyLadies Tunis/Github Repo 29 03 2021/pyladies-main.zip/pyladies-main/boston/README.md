PyLadies Boston
==========

From within boston/
```
pip install -r requirements.txt
mynt gen -f www
```
