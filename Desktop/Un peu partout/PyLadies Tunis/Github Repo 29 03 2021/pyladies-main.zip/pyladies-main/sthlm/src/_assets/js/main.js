$(document).ready(function() {
    var chapter_ids = '7660062';
    addUpcomingMeetups(chapter_ids);
    console.log('testing!');
});//end doc.ready
