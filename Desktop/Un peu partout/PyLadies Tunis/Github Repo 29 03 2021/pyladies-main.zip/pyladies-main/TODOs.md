## TODOs & Wishlist

* Update blog posts from 7 months to now
* CSS + Design (contact gal that made the geek girl graphic)
* Add upcoming Python + Open Source conferences (CFP links)
* Add info regarding lists like Systers.org, DevChix, SpeakUp.io, etc
* Mentor/Mentee request/forums
* Add books, tutorials, etc to Resources
* Pull in PyLadies personal blogs (maybe pull via RSS from specific tags of the personal blog)
* Add APIs for local meetup groups + twitter feeds (LS has JS code for this that could work)
